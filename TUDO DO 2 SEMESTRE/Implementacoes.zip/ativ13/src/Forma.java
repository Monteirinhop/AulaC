
public abstract class Forma {
	
	public abstract void coletarEntrada();
	
	public abstract void imprimir();
	
}
