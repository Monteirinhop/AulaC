
public class Gerente extends Funcionario {

	
	float calcularPag() {
		return salario;
	}

}
