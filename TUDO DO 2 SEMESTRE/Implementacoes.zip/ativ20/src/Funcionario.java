
public abstract class Funcionario {
	
	public String nome;
	public float salario;
	
	abstract float calcularPag();
}
